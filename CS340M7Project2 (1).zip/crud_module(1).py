from pymongo import MongoClient

class CRUD:
    def __init__(self, username, password):
        self.client = MongoClient(f"mongodb://{username}:{password}@nv-desktop-services.apporto.com:33016/")

        self.db = self.client["aac"]
    
    def read_query(self, query):
        return list(self.db.animals.find(query))
    def read(self, query):
        return self.read_query(query)
        

